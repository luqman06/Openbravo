package org.wirabumi.hris.timeandattendance.utility;

public class AttendancePerformanceBean {
	
	int harikerja;
	int totaljamkerja;
	int cuti;
	int perjalanandinas;
	int netharikerja;
	int nettotaljamkerja;
	int tidakmasuk;
	int terlambat;
	int durasiterlambat;
	int lupacheckin;
	int pulangcepat;
	int durasipulangcepat;
	int lupacheckout;
	
	public int getHarikerja() {
		return harikerja;
	}
	public void setHarikerja(int harikerja) {
		this.harikerja = harikerja;
	}
	public int getTotaljamkerja() {
		return totaljamkerja;
	}
	public void setTotaljamkerja(int totaljamkerja) {
		this.totaljamkerja = totaljamkerja;
	}
	public int getCuti() {
		return cuti;
	}
	public void setCuti(int cuti) {
		this.cuti = cuti;
	}
	public int getPerjalanandinas() {
		return perjalanandinas;
	}
	public void setPerjalanandinas(int perjalanadinas) {
		this.perjalanandinas = perjalanadinas;
	}
	public int getNetharikerja() {
		return netharikerja;
	}
	public void setNetharikerja(int netharikerja) {
		this.netharikerja = netharikerja;
	}
	public int getNettotaljamkerja() {
		return nettotaljamkerja;
	}
	public void setNettotaljamkerja(int nettotaljamkerja) {
		this.nettotaljamkerja = nettotaljamkerja;
	}
	public int getTidakmasuk() {
		return tidakmasuk;
	}
	public void setTidakmasuk(int tidakmasuk) {
		this.tidakmasuk = tidakmasuk;
	}
	public int getTerlambat() {
		return terlambat;
	}
	public void setTerlambat(int terlambat) {
		this.terlambat = terlambat;
	}
	public int getDurasiterlambat() {
		return durasiterlambat;
	}
	public void setDurasiterlambat(int durasiterlambat) {
		this.durasiterlambat = durasiterlambat;
	}
	public int getLupacheckin() {
		return lupacheckin;
	}
	public void setLupacheckin(int lupacheckin) {
		this.lupacheckin = lupacheckin;
	}
	public int getPulangcepat() {
		return pulangcepat;
	}
	public void setPulangcepat(int pulangcepat) {
		this.pulangcepat = pulangcepat;
	}
	public int getDurasipulangcepat() {
		return durasipulangcepat;
	}
	public void setDurasipulangcepat(int durasipulangcepat) {
		this.durasipulangcepat = durasipulangcepat;
	}
	public int getLupacheckout() {
		return lupacheckout;
	}
	public void setLupacheckout(int lupacheckout) {
		this.lupacheckout = lupacheckout;
	}
	
	
	
	

}
