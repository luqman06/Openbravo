package org.wirabumi.cam.process;

import java.math.BigDecimal;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;

import org.apache.log4j.Logger;
import org.hibernate.criterion.Restrictions;
import org.openbravo.base.secureApp.VariablesSecureApp;
import org.openbravo.dal.core.OBContext;
import org.openbravo.dal.service.OBCriteria;
import org.openbravo.dal.service.OBDal;
import org.openbravo.data.FieldProvider;
import org.openbravo.database.ConnectionProvider;
import org.openbravo.erpCommon.ad_forms.Account;
import org.openbravo.erpCommon.ad_forms.AcctSchema;
import org.openbravo.erpCommon.ad_forms.AcctServer;
import org.openbravo.erpCommon.ad_forms.DocLine;
import org.openbravo.erpCommon.ad_forms.Fact;
import org.openbravo.erpCommon.ad_forms.FactLine;
import org.openbravo.erpCommon.businessUtility.AccountingSchemaMiscData;
import org.openbravo.erpCommon.utility.SequenceIdData;
import org.openbravo.model.common.currency.Currency;
import org.openbravo.model.financialmgmt.accounting.coa.AccountingCombination;
import org.openbravo.model.financialmgmt.assetmgmt.Asset;
import org.openbravo.model.financialmgmt.assetmgmt.AssetAccounts;
import org.wirabumi.cam.WorkOrderAsset;

public class DocWorkOrder extends AcctServer {
	
	static Logger log4jDocWorkOrder = Logger.getLogger(DocWorkOrder.class);
	private String SeqNo = "0";

	@Override
	public void loadObjectFieldProvider(ConnectionProvider conn, String AD_Client_ID, String Id)
			throws ServletException {
		setObjectFieldProvider(DocWorkOrderData.select(conn, AD_Client_ID, Id));

	}

	@Override
	public boolean loadDocumentDetails(FieldProvider[] data, ConnectionProvider conn) {
		/*
		 * dipakai untuk mengisi
		 * 	DocumentType = AcctServer.DOCTYPE_MatInventory;
		 * 	C_Currency_ID = NO_CURRENCY;
		 * 	DateDoc = data[0].getField("MovementDate");
		 * 	loadDocumentType(); // lines require doc type
		 * 	Contained Objects:
		 * 		p_lines = loadLines(conn);
		 * 	setelah itu return true;
		 */
		DocumentType = "CAM_WO";
		C_Currency_ID = NO_CURRENCY;
		DateDoc = data[0].getField("movementdate");
		loadDocumentType();
		
		//Contained Objects:
		p_lines = loadLines(conn);
		return true;
	}

	private DocLine[] loadLines(ConnectionProvider conn) {
		ArrayList<Object> list = new ArrayList<Object>();
	    DocLineWorkOrderData[] data = null;
	    OBContext.setAdminMode(false);
	    try {
	      data = DocLineWorkOrderData.select(conn, Record_ID);
	      for (int i = 0; i < data.length; i++) {
	        String Line_ID = data[i].getField("cam_workorderasset_id");
	        String assetID = data[i].getField("a_asset_id");
	        DocLine docLine = new DocLine(DocumentType, Record_ID, Line_ID);
	        docLine.m_A_Asset_ID=assetID;
	        docLine.loadAttributes(data[i], this);
	        list.add(docLine);
	      }
	    } catch (ServletException e) {
	    	log4jDocWorkOrder.warn(e);
	    } finally {
	      OBContext.restorePreviousMode();
	    }
	    // Return Array
	    DocLine[] dl = new DocLine[list.size()];
	    list.toArray(dl);
	    return dl;
	}

	@Override
	public BigDecimal getBalance() {
		return BigDecimal.ZERO;
	}

	@Override
	public Fact createFact(AcctSchema as, ConnectionProvider conn, Connection con, VariablesSecureApp vars)
			throws ServletException {
		org.openbravo.model.financialmgmt.accounting.coa.AcctSchema accountingSchema = 
				OBDal.getInstance().get(org.openbravo.model.financialmgmt.accounting.coa.AcctSchema.class, as.m_C_AcctSchema_ID);
		// membuat object Fact as we know it, yang didalamnya ada array factLine.
		// dalam membuat factLine, dilakukan dengan memanggil method createLine.
		
		// Select specific definition
	    String strClassname =  DocWorkOrderData
	        .selectTemplateDoc(conn, as.m_C_AcctSchema_ID, DocumentType);
	    if (strClassname.equals(""))
	      strClassname = DocWorkOrderData.selectTemplate(conn, as.m_C_AcctSchema_ID, AD_Table_ID);
	    if (!strClassname.equals("")) {
	      try {
	        DocWorkOrderTemplate newTemplate = (DocWorkOrderTemplate) Class.forName(strClassname)
	            .newInstance();
	        return newTemplate.createFact(this, as, conn, con, vars);
	      } catch (Exception e) {
	    	  log4jDocWorkOrder.error("Error while creating new instance for DocInventoryTemplate - " + e);
	      }
	    }
		
	    C_Currency_ID = as.getC_Currency_ID();
	    
	    // create Fact Header
	    Fact fact = new Fact(this, as, Fact.POST_Actual);
	    String Fact_Acct_Group_ID = SequenceIdData.getUUID();
	    
	    // Line pointers
	    FactLine dr = null;
	    FactLine cr = null;
	    log4jDocWorkOrder.debug("CreateFact - before loop");
	    if (p_lines.length == 0) {
	      setStatus(STATUS_DocumentDisabled);
	    }
	    int validLines=0;
	    for (int i = 0; i < p_lines.length; i++) {
	      DocLine line = p_lines[i];
	      WorkOrderAsset woA = OBDal.getInstance().get(WorkOrderAsset.class, line.m_TrxLine_ID);
	      if (woA==null)
	    	  continue; //invalid work order asset record;
	      
	      if (!woA.isDisposed())
	    	  continue; //sekarang ini hanya asset disposal saja yg di support.
	      
	      //do post logic here	      
	      Asset asset = woA.getAsset();
	      if (asset==null)
	    	  continue; //no asset to be processed;
	      line.m_A_Asset_ID=asset.getId();
	      Currency costCurrency = asset.getCurrency();
	      if (costCurrency==null)
	    	  continue; //has no currency
	      if (asset.isFullyDepreciated())
	    	  continue; //asset has no book value;
	      if (!asset.isDepreciate())
	    	  continue; //non financial asset;
	      BigDecimal hargaperolehan = asset.getAssetValue();
	      if (hargaperolehan==null || hargaperolehan.equals(BigDecimal.ZERO))
	    	  continue; //has no asset value;
	      BigDecimal akumulasidepresiasi = asset.getDepreciatedValue();
	      if (akumulasidepresiasi==null)
	    	  akumulasidepresiasi=BigDecimal.ZERO;
	      BigDecimal prevdepresiasi = asset.getPreviouslyDepreciatedAmt();
	      if (prevdepresiasi==null)
	    	  prevdepresiasi=BigDecimal.ZERO;
	      BigDecimal nilaibuku = hargaperolehan.subtract(akumulasidepresiasi).subtract(prevdepresiasi);
	      if (nilaibuku.equals(BigDecimal.ZERO))
	    	  continue; //have no book value;
	      
	      String costs = nilaibuku.toString();
	      BigDecimal b_Costs = nilaibuku;
	      OBCriteria<AssetAccounts> assetAccountingC = OBDal.getInstance().createCriteria(AssetAccounts.class);
	      assetAccountingC.add(Restrictions.eq(AssetAccounts.PROPERTY_ASSET, asset));
	      assetAccountingC.add(Restrictions.eq(AssetAccounts.PROPERTY_ACCOUNTINGSCHEMA, accountingSchema));
	      List<AssetAccounts> assetAccountingL = assetAccountingC.list();
	      if (assetAccountingL.size()==0){
	    	  Map<String, String> parameters = new HashMap<String, String>();
	    	  parameters.put("trx", woA.getIdentifier());
	    	  parameters.put("asset", asset.getIdentifier());
	    	  setMessageResult(conn, STATUS_InvalidAccount, "error", parameters);
	    	  continue; //no accounting configuration
	      }
	      AssetAccounts assetAccounting = assetAccountingL.get(0);
	      AccountingCombination acAkumulasiDepresiasi = assetAccounting.getAccumulatedDepreciation();
	      AccountingCombination acDisposalLoss = assetAccounting.getDisposalLoss();
	      if (acAkumulasiDepresiasi==null || acDisposalLoss==null){
	    	  Map<String, String> parameters = new HashMap<String, String>();
	    	  parameters.put("trx", woA.getIdentifier());
	    	  parameters.put("asset", asset.getIdentifier());
	    	  setMessageResult(conn, STATUS_InvalidAccount, "error", parameters);
	    	  continue; //no accounting configuration
	      }
	        
	      log4jDocWorkOrder.debug("CreateFact - before DR - Costs: " + costs);
	      // Asset disposal loss DR
	      Account akunDisposalLoss = new Account(conn, acDisposalLoss.getId());
	      dr = fact.createLine(line, akunDisposalLoss, costCurrency.getId(), costs, Fact_Acct_Group_ID,
	          nextSeqNo(SeqNo), DocumentType, conn);
	      // may be zero difference - no line created.
	      if (dr == null) {
	        continue;
	      }
	      
	      log4jDocWorkOrder.debug("CreateFact - before CR");
	      // Asset accumulation depreciation CR
	      Account akunAkumulasiDepresiasi = new Account(conn, acAkumulasiDepresiasi.getId());
	      cr = fact.createLine(line, akunAkumulasiDepresiasi, costCurrency.getId(), (b_Costs.negate()).toString(),
	          Fact_Acct_Group_ID, nextSeqNo(SeqNo), DocumentType, conn);
	      if (cr == null) {
	        continue;
	      }
	      
	      validLines++;
	    }
	    
	    if (validLines==0) {
	      setStatus(STATUS_DocumentDisabled);
	    }
	    
	    log4jDocWorkOrder.debug("CreateFact - after loop");
	    SeqNo = "0";
	    return fact;
		
	}

	@Override
	public boolean getDocumentConfirmation(ConnectionProvider conn, String strRecordId) {
		return true;
	}
	
	public String nextSeqNo(String oldSeqNo) {
		log4jDocWorkOrder.debug("DocInventory - oldSeqNo = " + oldSeqNo);
	    BigDecimal seqNo = new BigDecimal(oldSeqNo);
	    SeqNo = (seqNo.add(new BigDecimal("10"))).toString();
	    log4jDocWorkOrder.debug("DocInventory - nextSeqNo = " + SeqNo);
	    return SeqNo;
	}

}
