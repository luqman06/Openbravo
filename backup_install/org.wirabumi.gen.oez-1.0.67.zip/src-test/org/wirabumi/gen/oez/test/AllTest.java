package org.wirabumi.gen.oez.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * 
 * Test for org.openbravo.advpaymentmngt
 * 
 */

@RunWith(Suite.class)
@Suite.SuiteClasses({
  
    // Master Data Configuration
    DocumentRoutingTest.class
    })


public class AllTest {
	
}
