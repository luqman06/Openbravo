package org.wirabumi.gen.oez.ad_process;

public class PendingWorkRequirementBean {
	
	private String id, documentNo, ma_processplan_id, ma_process_id, ma_sequence_id,
	processplan_code, processplan_name, activity_name, activity_code,
	operation_name, operation_code;
	private double wr_quantity, quantity, donequantity, pendingquantity;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDocumentNo() {
		return documentNo;
	}
	public void setDocumentNo(String documentNo) {
		this.documentNo = documentNo;
	}
	public String getMa_processplan_id() {
		return ma_processplan_id;
	}
	public void setMa_processplan_id(String ma_processplan_id) {
		this.ma_processplan_id = ma_processplan_id;
	}
	public String getMa_process_id() {
		return ma_process_id;
	}
	public void setMa_process_id(String ma_process_id) {
		this.ma_process_id = ma_process_id;
	}
	public String getMa_sequence_id() {
		return ma_sequence_id;
	}
	public void setMa_sequence_id(String ma_sequence_id) {
		this.ma_sequence_id = ma_sequence_id;
	}
	public String getProcessplan_code() {
		return processplan_code;
	}
	public void setProcessplan_code(String processplan_code) {
		this.processplan_code = processplan_code;
	}
	public String getProcessplan_name() {
		return processplan_name;
	}
	public void setProcessplan_name(String processplan_name) {
		this.processplan_name = processplan_name;
	}
	public String getActivity_name() {
		return activity_name;
	}
	public void setActivity_name(String activity_name) {
		this.activity_name = activity_name;
	}
	public String getActivity_code() {
		return activity_code;
	}
	public void setActivity_code(String activity_code) {
		this.activity_code = activity_code;
	}
	public String getOperation_name() {
		return operation_name;
	}
	public void setOperation_name(String operation_name) {
		this.operation_name = operation_name;
	}
	public String getOperation_code() {
		return operation_code;
	}
	public void setOperation_code(String operation_code) {
		this.operation_code = operation_code;
	}
	public double getWr_quantity() {
		return wr_quantity;
	}
	public void setWr_quantity(double wr_quantity) {
		this.wr_quantity = wr_quantity;
	}
	public double getQuantity() {
		return quantity;
	}
	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}
	public double getDonequantity() {
		return donequantity;
	}
	public void setDonequantity(double donequantity) {
		this.donequantity = donequantity;
	}
	public double getPendingquantity() {
		return pendingquantity;
	}
	public void setPendingquantity(double pendingquantity) {
		this.pendingquantity = pendingquantity;
	}
	
	

}
